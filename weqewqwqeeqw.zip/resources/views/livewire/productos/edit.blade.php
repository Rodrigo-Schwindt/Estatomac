@extends('layouts.admin')

@section('content')
<div class="max-w-5xl mx-auto space-y-8 animate-fadeIn">
    <div class="flex items-center justify-between">
        <h2 class="text-2xl font-semibold text-slate-900">Editar Producto</h2>
        <a href="{{ route('productos.index') }}" 
           class="inline-flex items-center gap-2 px-4 py-2 bg-slate-600 text-white rounded-md hover:bg-slate-700 transition">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/>
            </svg>
            Volver
        </a>
    </div>

    <form action="{{ route('productos.update', $producto) }}" method="POST" enctype="multipart/form-data" class="bg-white border border-slate-200 rounded-md shadow-sm p-8 space-y-6">
        @csrf
        @method('PUT')
        
        <input type="hidden" name="deleted_gallery[]" id="deletedGallery">

        <div class="space-y-6">
            <h3 class="text-lg font-semibold text-slate-900 border-b pb-2">Información Básica</h3>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div class="md:col-span-2">
                    <label for="title" class="block text-sm font-medium text-slate-700 mb-2">
                        Título <span class="text-red-500">*</span>
                    </label>
                    <input type="text" 
                           name="title" 
                           id="title" 
                           value="{{ old('title', $producto->title) }}"
                           class="w-full px-4 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-600 @error('title') border-red-500 @enderror"
                           required>
                    @error('title')
                        <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                    @enderror
                </div>

                <div>
                    <label for="code" class="block text-sm font-medium text-slate-700 mb-2">Código</label>
                    <input type="text" 
                           name="code" 
                           id="code" 
                           value="{{ old('code', $producto->code) }}"
                           class="w-full px-4 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-600 @error('code') border-red-500 @enderror">
                    @error('code')
                        <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                    @enderror
                </div>

                <div>
                    <label for="order" class="block text-sm font-medium text-slate-700 mb-2">Orden</label>
                    <input type="text" 
                           name="order" 
                           id="order" 
                           value="{{ old('order', $producto->order) }}"
                           class="w-full px-4 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-600 @error('order') border-red-500 @enderror">
                    @error('order')
                        <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                    @enderror
                </div>

                <div class="md:col-span-2">
                    <label for="marcas" class="block text-sm font-medium text-slate-700 mb-2">Marcas</label>
                    <select name="marcas[]" 
                            id="marcas" 
                            multiple
                            class="w-full px-4 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-600 @error('marcas') border-red-500 @enderror"
                            style="height: 150px;">
                        @foreach($marcas as $marca)
                            <option value="{{ $marca->id }}" 
                                {{ (is_array(old('marcas')) ? in_array($marca->id, old('marcas')) : $producto->marcas->contains($marca->id)) ? 'selected' : '' }}>
                                {{ $marca->title }}
                            </option>
                        @endforeach
                    </select>
                    <p class="mt-1 text-xs text-slate-500">Mantén presionado Ctrl (Cmd en Mac) para seleccionar múltiples opciones</p>
                    @error('marcas')
                        <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                    @enderror
                </div>

                <div class="md:col-span-2">
                    <label for="modelos" class="block text-sm font-medium text-slate-700 mb-2">Modelos</label>
                    <select name="modelos[]" 
                            id="modelos" 
                            multiple
                            class="w-full px-4 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-600 @error('modelos') border-red-500 @enderror"
                            style="height: 150px;">
                        @foreach($modelos as $modelo)
                            <option value="{{ $modelo->id }}" 
                                {{ (is_array(old('modelos')) ? in_array($modelo->id, old('modelos')) : $producto->modelos->contains($modelo->id)) ? 'selected' : '' }}>
                                {{ $modelo->title }}
                            </option>
                        @endforeach
                    </select>
                    <p class="mt-1 text-xs text-slate-500">Mantén presionado Ctrl (Cmd en Mac) para seleccionar múltiples opciones</p>
                    @error('modelos')
                        <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                    @enderror
                </div>

                <div>
                    <label for="categoria_id" class="block text-sm font-medium text-slate-700 mb-2">Categoría</label>
                    <select name="categoria_id" 
                            id="categoria_id" 
                            class="w-full px-4 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-600 @error('categoria_id') border-red-500 @enderror">
                        <option value="">Seleccionar categoría</option>
                        @foreach($categorias as $categoria)
                            <option value="{{ $categoria->id }}" {{ old('categoria_id', $producto->categoria_id) == $categoria->id ? 'selected' : '' }}>
                                {{ $categoria->title }}
                            </option>
                        @endforeach
                    </select>
                    @error('categoria_id')
                        <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                    @enderror
                </div>

                <div>
                    <label for="visible" class="block text-sm font-medium text-slate-700 mb-2">
                        Visibilidad <span class="text-red-500">*</span>
                    </label>
                    <select name="visible" 
                            id="visible" 
                            class="w-full px-4 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-600 @error('visible') border-red-500 @enderror"
                            required>
                        <option value="1" {{ old('visible', $producto->visible) == '1' ? 'selected' : '' }}>Visible</option>
                        <option value="0" {{ old('visible', $producto->visible) == '0' ? 'selected' : '' }}>Oculto</option>
                    </select>
                    @error('visible')
                        <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                    @enderror
                </div>

                <div>
                    <label for="nuevo" class="block text-sm font-medium text-slate-700 mb-2">
                        Tipo <span class="text-red-500">*</span>
                    </label>
                    <select name="nuevo" 
                            id="nuevo" 
                            class="w-full px-4 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-600 @error('nuevo') border-red-500 @enderror"
                            required>
                        <option value="nuevo" {{ old('nuevo', $producto->nuevo) == 'nuevo' ? 'selected' : '' }}>Nuevo</option>
                        <option value="recambio" {{ old('nuevo', $producto->nuevo) == 'recambio' ? 'selected' : '' }}>Recambio</option>
                    </select>
                    @error('nuevo')
                        <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                    @enderror
                </div>

                <div>
                    <label for="destacado" class="block text-sm font-medium text-slate-700 mb-2">
                        Destacado <span class="text-red-500">*</span>
                    </label>
                    <select name="destacado" 
                            id="destacado" 
                            class="w-full px-4 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-600 @error('destacado') border-red-500 @enderror"
                            required>
                        <option value="0" {{ old('destacado', $producto->destacado) == '0' ? 'selected' : '' }}>No</option>
                        <option value="1" {{ old('destacado', $producto->destacado) == '1' ? 'selected' : '' }}>Sí</option>
                    </select>
                    @error('destacado')
                        <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                    @enderror
                </div>

                <div>
                    <label for="oferta" class="block text-sm font-medium text-slate-700 mb-2">
                        Oferta <span class="text-red-500">*</span>
                    </label>
                    <select name="oferta" 
                            id="oferta" 
                            class="w-full px-4 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-600 @error('oferta') border-red-500 @enderror"
                            required>
                        <option value="0" {{ old('oferta', $producto->oferta) == '0' ? 'selected' : '' }}>No</option>
                        <option value="1" {{ old('oferta', $producto->oferta) == '1' ? 'selected' : '' }}>Sí</option>
                    </select>
                    @error('oferta')
                        <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                    @enderror
                </div>

                <div>
                    <label for="importados" class="block text-sm font-medium text-slate-700 mb-2">
                        Importados <span class="text-red-500">*</span>
                    </label>
                    <select name="importados" 
                            id="importados" 
                            class="w-full px-4 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-600 @error('importados') border-red-500 @enderror"
                            required>
                        <option value="0" {{ old('importados', $producto->importados ?? 0) == '0' ? 'selected' : '' }}>No</option>
                        <option value="1" {{ old('importados', $producto->importados ?? 0) == '1' ? 'selected' : '' }}>Sí</option>
                    </select>
                    @error('importados')
                        <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                    @enderror
                </div>

                <div>
                    <label for="precio" class="block text-sm font-medium text-slate-700 mb-2">
                        Precio <span class="text-red-500">*</span>
                    </label>
                    <input type="number" 
                           name="precio" 
                           id="precio" 
                           step="0.01"
                           min="0"
                           value="{{ old('precio', $producto->precio) }}"
                           class="w-full px-4 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-600 @error('precio') border-red-500 @enderror"
                           required>
                    @error('precio')
                        <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                    @enderror
                </div>

                <div>
                    <label for="descuento" class="block text-sm font-medium text-slate-700 mb-2">Descuento</label>
                    <input type="number" 
                           name="descuento" 
                           id="descuento" 
                           step="0.01"
                           min="0"
                           value="{{ old('descuento', $producto->descuento) }}"
                           class="w-full px-4 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-600 @error('descuento') border-red-500 @enderror">
                    @error('descuento')
                        <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                    @enderror
                </div>
            </div>
        </div>

        <div class="space-y-6" id="subcategoriasSection" style="display: {{ $producto->categoria_id && $subcategorias->count() > 0 ? 'block' : 'none' }};">
            <h3 class="text-lg font-semibold text-slate-900 border-b pb-2">Características del Producto</h3>
            
            <div id="subcategoriasContainer" class="space-y-4">
                @foreach($subcategorias as $subcategoria)
                    @php
                        $pivotValor = $producto->subcategorias->find($subcategoria->id)?->pivot->valor ?? '';
                    @endphp
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 border border-slate-200 rounded-md bg-slate-50">
                        <div>
                            <label class="block text-sm font-medium text-slate-700 mb-2">
                                {{ $subcategoria->title }}
                            </label>
                        </div>
                        <div>
                            <input type="hidden" name="subcategorias[{{ $subcategoria->id }}][id]" value="{{ $subcategoria->id }}">
                            <input type="text" 
                                   name="subcategorias[{{ $subcategoria->id }}][valor]" 
                                   value="{{ old('subcategorias.'.$subcategoria->id.'.valor', $pivotValor) }}"
                                   placeholder="Ingrese valor"
                                   class="w-full px-4 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-600">
                        </div>
                    </div>
                @endforeach
            </div>
        </div>

        <div class="space-y-6">
            <h3 class="text-lg font-semibold text-slate-900 border-b pb-2">Imagen Principal</h3>
            
            <div>
                @if($producto->image)
                    <div class="mb-4">
                        <img src="{{ asset('storage/' . $producto->image) }}" 
                             alt="{{ $producto->title }}" 
                             class="w-32 h-32 object-cover rounded-md shadow-sm">
                    </div>
                @endif
                <label for="image" class="block text-sm font-medium text-slate-700 mb-2">Cambiar Imagen</label>
                <input type="file" 
                       name="image" 
                       id="image" 
                       accept="image/*"
                       class="w-full px-4 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-600 @error('image') border-red-500 @enderror"
                       onchange="previewMainImage(event)">
                @error('image')
                    <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                @enderror
                <div id="mainImagePreview" class="mt-4 hidden">
                    <img src="" alt="Preview" class="w-32 h-32 object-cover rounded-md shadow-sm">
                </div>
            </div>
        </div>

        <div class="space-y-6">
            <h3 class="text-lg font-semibold text-slate-900 border-b pb-2">Galería de Imágenes</h3>
            
            @if($producto->gallery->count() > 0)
                <div class="grid grid-cols-4 gap-4">
                    @foreach($producto->gallery as $image)
                        <div class="relative gallery-item" data-id="{{ $image->id }}">
                            <img src="{{ asset('storage/' . $image->image) }}" 
                                 alt="Gallery" 
                                 class="w-full h-24 object-cover rounded-md shadow-sm">
                            <button type="button" 
                                    onclick="removeGalleryImage({{ $image->id }})"
                                    class="absolute -top-2 -right-2 bg-red-600 text-white rounded-full p-1 hover:bg-red-700 transition">
                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                                </svg>
                            </button>
                        </div>
                    @endforeach
                </div>
            @endif
            
            <div>
                <label for="gallery" class="block text-sm font-medium text-slate-700 mb-2">Agregar Más Imágenes</label>
                <input type="file" 
                       name="gallery[]" 
                       id="gallery" 
                       accept="image/*"
                       multiple
                       class="w-full px-4 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-600 @error('gallery.*') border-red-500 @enderror"
                       onchange="previewGallery(event)">
                <p class="mt-1 text-xs text-slate-500">Puedes seleccionar múltiples imágenes</p>
                @error('gallery.*')
                    <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                @enderror
                <div id="galleryPreview" class="mt-4 grid grid-cols-4 gap-4 hidden">
                </div>
            </div>
        </div>

        <div class="flex gap-4 pt-6 border-t">
            <button type="submit" 
                    class="px-6 py-2.5 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition">
                Actualizar Producto
            </button>
            <a href="{{ route('productos.index') }}" 
               class="px-6 py-2.5 bg-slate-200 text-slate-700 rounded-md hover:bg-slate-300 transition">
                Cancelar
            </a>
        </div>
    </form>
</div>

<style>
@keyframes fadeIn { from { opacity:0; transform:translateY(8px) } to { opacity:1; transform:translateY(0) } }
.animate-fadeIn { animation: fadeIn .35s ease; }
</style>

<script>
let deletedGallery = [];

document.getElementById('categoria_id').addEventListener('change', function() {
    const categoriaId = this.value;
    const subcategoriasSection = document.getElementById('subcategoriasSection');
    const subcategoriasContainer = document.getElementById('subcategoriasContainer');
    
    subcategoriasContainer.innerHTML = '';
    subcategoriasSection.style.display = 'none';
    
    if (categoriaId) {
        fetch(`/admin/productos/subcategorias/${categoriaId}`)
            .then(response => response.json())
            .then(data => {
                if (data.length > 0) {
                    subcategoriasSection.style.display = 'block';
                    
                    data.forEach(subcategoria => {
                        const html = `
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 border border-slate-200 rounded-md bg-slate-50">
                                <div>
                                    <label class="block text-sm font-medium text-slate-700 mb-2">
                                        ${subcategoria.title}
                                        ${subcategoria.title2 ? '<span class="text-slate-500 text-xs"> (' + subcategoria.title2 + ')</span>' : ''}
                                    </label>
                                </div>
                                <div>
                                    <input type="hidden" name="subcategorias[${subcategoria.id}][id]" value="${subcategoria.id}">
                                    <input type="text" 
                                           name="subcategorias[${subcategoria.id}][valor]" 
                                           placeholder="Ingrese valor"
                                           class="w-full px-4 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-600">
                                </div>
                            </div>
                        `;
                        subcategoriasContainer.insertAdjacentHTML('beforeend', html);
                    });
                }
            })
            .catch(error => console.error('Error:', error));
    }
});

function previewMainImage(event) {
    const preview = document.getElementById('mainImagePreview');
    const img = preview.querySelector('img');
    
    if (event.target.files && event.target.files[0]) {
        const reader = new FileReader();
        reader.onload = function(e) {
            img.src = e.target.result;
            preview.classList.remove('hidden');
        }
        reader.readAsDataURL(event.target.files[0]);
    }
}

function previewGallery(event) {
    const preview = document.getElementById('galleryPreview');
    preview.innerHTML = '';
    
    if (event.target.files && event.target.files.length > 0) {
        preview.classList.remove('hidden');
        
        Array.from(event.target.files).forEach(file => {
            const reader = new FileReader();
            reader.onload = function(e) {
                const div = document.createElement('div');
                div.className = 'relative';
                div.innerHTML = `
                    <img src="${e.target.result}" class="w-full h-24 object-cover rounded-md shadow-sm">
                `;
                preview.appendChild(div);
            }
            reader.readAsDataURL(file);
        });
    } else {
        preview.classList.add('hidden');
    }
}

function removeGalleryImage(id) {
    if (confirm('¿Estás seguro de eliminar esta imagen?')) {
        deletedGallery.push(id);
        updateDeletedInput();
        document.querySelector(`.gallery-item[data-id="${id}"]`).remove();
    }
}

function updateDeletedInput() {
    const container = document.getElementById('deletedGallery').parentElement;
    container.querySelectorAll('input[name="deleted_gallery[]"]').forEach(input => input.remove());
    
    deletedGallery.forEach(id => {
        const input = document.createElement('input');
        input.type = 'hidden';
        input.name = 'deleted_gallery[]';
        input.value = id;
        container.appendChild(input);
    });
}
</script>
@endsection