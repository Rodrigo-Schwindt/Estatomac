<?php

namespace App\Livewire\Zona;

use Livewire\Component;
use App\Models\Categoria;
use App\Models\Marca;
use App\Models\Producto;
use App\Models\Carrito;
use Livewire\Attributes\Layout;
use Illuminate\Support\Facades\Auth;

#[Layout('layouts.zone')]
class ProductosZona extends Component
{
    public $search = '';
    public $tipo = null;
    public $categoriaId = null;
    public $marcaId = null;
    public $modeloId = null;
    public $codigo = null;
    public $equivalencia = null;
    public array $cantidades = [];
    public $filtrosSubcategorias = [];
    public $aplicarFiltros = false;
    public $mostrarModalOfertas = false;
    public $productosEnOferta = [];
    public $productoActualModal = 0;

    public function mount()
    {
        if (!Auth::guard('cliente')->check()) {
            session()->flash('openLoginModal', true);
            return redirect()->route('home');
        }

        if (session()->has('toast')) {
            $toast = session('toast');
            // Usamos self::dispatch para que se ejecute apenas cargue el componente
            $this->dispatch('producto-agregado', [
                'message' => $toast['message'],
                'type' => $toast['type']
            ]);
        }
        
        $this->verificarModalOfertas();

        if (session()->has('search')) {
            $this->search = session('search');
        }
        if (session()->has('tipo')) {
            $this->tipo = session('tipo');
        }
        if (session()->has('categoriaId')) {
            $this->categoriaId = session('categoriaId');
        }
        if (session()->has('marcaId')) {
            $this->marcaId = session('marcaId');
        }
        if (session()->has('modeloId')) {
            $this->modeloId = session('modeloId');
        }
        if (session()->has('codigo')) {
            $this->codigo = session('codigo');
        }
        if (session()->has('equivalencia')) {
            $this->equivalencia = session('equivalencia');
        }
        if (session()->has('filtrosSubcategorias')) {
            $this->filtrosSubcategorias = session('filtrosSubcategorias');
        }
        if (session()->has('aplicarFiltros')) {
            $this->aplicarFiltros = session('aplicarFiltros');
        }
    }

    public function verificarModalOfertas()
    {
        $clienteId = Auth::guard('cliente')->id();
        $cacheKey = 'modal_ofertas_' . $clienteId;
        $ultimaVista = session($cacheKey);
        
        // Si no hay registro o pasaron más de 5 minutos (300 segundos)
        if (!$ultimaVista || (time() - $ultimaVista) > 140) {
            $this->productosEnOferta = Producto::where('visible', true)
                ->where('oferta', true)
                ->with(['gallery'])
                ->get()
                ->toArray();
            
            if (count($this->productosEnOferta) > 0) {
                // Delay de 2 segundos antes de mostrar
                $this->dispatch('mostrar-modal-ofertas-delayed');
                session([$cacheKey => time()]);
            }
        }
    }

    public function cerrarModalOfertas()
    {
        $this->mostrarModalOfertas = false;
    }

    public function siguienteProductoModal()
    {
        if ($this->productoActualModal < count($this->productosEnOferta) - 1) {
            $this->productoActualModal++;
        } else {
            // Volver al inicio
            $this->productoActualModal = 0;
        }
    }

    public function anteriorProductoModal()
    {
        if ($this->productoActualModal > 0) {
            $this->productoActualModal--;
        }
    }

    public function agregarAlCarritoDesdeModal($productoId)
    {
        $this->agregarAlCarrito($productoId);
    }

    public function agregarAlCarrito($productoId)
    {
        $producto = Producto::find($productoId);
        
        if (!$producto) {
            $this->dispatch('show-toast', message: 'Producto no encontrado', type: 'error');
            return;
        }

        $cantidad = $this->cantidades[$productoId] ?? 1;
        $clienteId = Auth::guard('cliente')->id();

        $itemCarrito = Carrito::where('cliente_id', $clienteId)
            ->where('producto_id', $productoId)
            ->first();

        if ($itemCarrito) {
            $itemCarrito->cantidad += $cantidad;
            $itemCarrito->save();
            $mensaje = "¡{$producto->code} actualizado en el carrito!";
        } else {
            Carrito::create([
                'cliente_id' => $clienteId,
                'producto_id' => $productoId,
                'cantidad' => $cantidad,
                'precio_unitario' => $producto->precio,
                'descuento_unitario' => $producto->descuento ?? 0,
            ]);
            $mensaje = "¡{$producto->code} agregado al carrito!";
        }

        // Emitir evento para el nuevo toast
        $this->dispatch('producto-agregado', ['message' => $mensaje]);
        $this->dispatch('carrito-actualizado');
    }

    public function updatedCategoriaId()
    {
        $this->filtrosSubcategorias = [];
    }

    public function updatedMarcaId()
    {
        $this->modeloId = null;
    }

    public function buscar()
    {
        $this->aplicarFiltros = true;
    }

    public function limpiarFiltros()
    {
        $this->reset([
            'search',
            'tipo',
            'categoriaId',
            'filtrosSubcategorias',
            'marcaId',
            'modeloId',
            'codigo',
            'equivalencia',
            'aplicarFiltros',
        ]);
    }

    public function hayFiltrosActivos(): bool
    {
        return $this->aplicarFiltros && (
            filled($this->search)
            || filled($this->tipo)
            || filled($this->categoriaId)
            || !empty(array_filter($this->filtrosSubcategorias))
            || filled($this->marcaId)
            || filled($this->modeloId)
            || filled($this->codigo)
            || filled($this->equivalencia)
        );
    }

    public function seleccionarCategoria($categoriaId)
    {
        $this->categoriaId = $categoriaId;
        $this->buscar();
    }

    public function toggleTipo($valor)
    {
        if ($this->tipo === $valor) {
            $this->tipo = null;
        } else {
            $this->tipo = $valor;
        }
    }

    public function incrementar($productoId)
    {
        if (!isset($this->cantidades[$productoId])) {
            $this->cantidades[$productoId] = 1;
        }

        $this->cantidades[$productoId]++;
    }

    public function decrementar($productoId)
    {
        if (
            isset($this->cantidades[$productoId]) &&
            $this->cantidades[$productoId] > 1
        ) {
            $this->cantidades[$productoId]--;
        }
    }

    public function render()
    {
        $categorias = Categoria::with('subcategorias')
            ->orderBy('order')
            ->get();

        $marcas = Marca::with('modelos')
            ->orderBy('order')
            ->get();

        $subcategoriasActuales = [];
        if ($this->categoriaId) {
            $subcategoriasActuales = Categoria::find($this->categoriaId)
                ?->subcategorias()
                ->orderBy('order')
                ->get() ?? collect();
        }

        $hayFiltros = $this->hayFiltrosActivos();

        $productos = $this->filtrarProductos();

        foreach ($productos as $producto) {
            if (!isset($this->cantidades[$producto->id])) {
                $this->cantidades[$producto->id] = 1;
            }
        }

        $equivalenciasDisponibles = \App\Models\Equivalencia::select('code', 'title')
            ->whereNotNull('code')
            ->distinct()
            ->orderBy('code')
            ->get();

        return view('livewire.zona.productos-zona', [
            'categorias' => $categorias,
            'marcas' => $marcas,
            'productos' => $productos,
            'hayFiltros' => $hayFiltros,
            'subcategoriasActuales' => $subcategoriasActuales,
            'equivalenciasDisponibles' => $equivalenciasDisponibles,
        ]);
    }

    protected function filtrarProductos()
    {
        $query = Producto::query()
            ->with([
                'marca',
                'modelo',
                'categoria',
                'subcategorias',
                'equivalencias',
                'gallery',
            ])
            ->where('visible', true);

        if ($this->tipo) {
            $query->where('nuevo', $this->tipo);
        }

        if ($this->categoriaId) {
            $query->where('categoria_id', $this->categoriaId);
        }

        if (!empty(array_filter($this->filtrosSubcategorias))) {
            foreach ($this->filtrosSubcategorias as $subcategoriaId => $valor) {
                if (!empty($valor)) {
                    $query->whereHas('subcategorias', function ($q) use ($subcategoriaId, $valor) {
                        $q->where('subcategorias.id', $subcategoriaId)
                          ->where('producto_subcategoria.valor', 'like', "%{$valor}%");
                    });
                }
            }
        }

        if ($this->marcaId) {
            $query->where('marca_id', $this->marcaId);
        }

        if ($this->modeloId) {
            $query->where('modelo_id', $this->modeloId);
        }

        if ($this->codigo) {
            $query->where('title', 'like', "%{$this->codigo}%");
        }

        if ($this->equivalencia) {
            $query->whereHas('equivalencias', function ($q) {
                $q->where('code', 'like', "%{$this->equivalencia}%");
            });
        }

        if ($this->search) {
            $query->where(function ($q) {
                $q->where('title', 'like', "%{$this->search}%")
                  ->orWhereHas('categoria', fn ($c) => $c->where('title', 'like', "%{$this->search}%"))
                  ->orWhereHas('marca', fn ($m) => $m->where('title', 'like', "%{$this->search}%"))
                  ->orWhereHas('modelo', fn ($m) => $m->where('title', 'like', "%{$this->search}%"))
                  ->orWhereHas('subcategorias', fn ($s) => $s->where('title', 'like', "%{$this->search}%"))
                  ->orWhereHas('equivalencias', fn ($e) => $e->where('code', 'like', "%{$this->search}%"));
            });
        }

        return $query->get();
    }
}