<?php

namespace App\Livewire\Vistas\Productos;

use Livewire\Component;
use App\Models\Categoria;
use App\Models\Marca;
use App\Models\Producto;
use App\Models\Banner;
use Livewire\Attributes\Layout;

#[Layout('layouts.public')]
class ProductosPage extends Component
{
    public $search = '';
    public $tipo = null;
    public $categoriaId = null;
    public $marcaId = null;
    public $modeloId = null;
    public $codigo = null;
    public $equivalencia = null;
    
    public $filtrosSubcategorias = [];
    
    public $aplicarFiltros = false;

    public function updatedCategoriaId()
    {
        $this->filtrosSubcategorias = [];
    }

    public function updatedMarcaId()
    {
        $this->modeloId = null;
    }

    public function buscar()
    {
        $this->aplicarFiltros = true;
    }

    public function limpiarFiltros()
    {
        $this->reset([
            'search',
            'tipo',
            'categoriaId',
            'filtrosSubcategorias',
            'marcaId',
            'modeloId',
            'codigo',
            'equivalencia',
            'aplicarFiltros',
        ]);
    }

    public function hayFiltrosActivos(): bool
    {
        return $this->aplicarFiltros && (
            filled($this->search)
            || filled($this->tipo)
            || filled($this->categoriaId)
            || !empty(array_filter($this->filtrosSubcategorias))
            || filled($this->marcaId)
            || filled($this->modeloId)
            || filled($this->codigo)
            || filled($this->equivalencia)
        );
    }

    public function render()
    {
        $categorias = Categoria::with('subcategorias')
            ->orderBy('order')
            ->get();
    
        $marcas = Marca::with('modelos')
            ->orderBy('order')
            ->get();
    
        $banner = Banner::forSection('categorias')->first();
    
        $subcategoriasActuales = [];
        if ($this->categoriaId) {
            $subcategoriasActuales = Categoria::find($this->categoriaId)
                ?->subcategorias()
                ->orderBy('order')
                ->get() ?? collect();
        }
    
        $hayFiltros = $this->hayFiltrosActivos();
        $productos = $hayFiltros ? $this->filtrarProductos() : collect();
        
        $equivalenciasDisponibles = \App\Models\Equivalencia::select('code', 'title')
            ->whereNotNull('code')
            ->distinct()
            ->orderBy('code')
            ->get();
    
        return view('livewire.vistas.productos.productos-page', [
            'categorias' => $categorias,
            'marcas' => $marcas,
            'productos' => $productos,
            'hayFiltros' => $hayFiltros,
            'banner' => $banner,
            'subcategoriasActuales' => $subcategoriasActuales,
            'equivalenciasDisponibles' => $equivalenciasDisponibles,
        ]);
    }
    public function mount()
{
    if (session()->has('search')) {
        $this->search = session('search');
    }
    if (session()->has('tipo')) {
        $this->tipo = session('tipo');
    }
    if (session()->has('categoriaId')) {
        $this->categoriaId = session('categoriaId');
    }
    if (session()->has('marcaId')) {
        $this->marcaId = session('marcaId');
    }
    if (session()->has('modeloId')) {
        $this->modeloId = session('modeloId');
    }
    if (session()->has('codigo')) {
        $this->codigo = session('codigo');
    }
    if (session()->has('equivalencia')) {
        $this->equivalencia = session('equivalencia');
    }
    if (session()->has('filtrosSubcategorias')) {
        $this->filtrosSubcategorias = session('filtrosSubcategorias');
    }
    if (session()->has('aplicarFiltros')) {
        $this->aplicarFiltros = session('aplicarFiltros');
    }
}
public function seleccionarCategoria($categoriaId)
{
    $this->categoriaId = $categoriaId;
    $this->buscar();
}
    public function toggleTipo($valor)
{
    if ($this->tipo === $valor) {
        $this->tipo = null;
    } else {
        $this->tipo = $valor;
    }
}

    protected function filtrarProductos()
    {
        $query = Producto::query()
            ->with([
                'marca',
                'modelo',
                'categoria',
                'subcategorias',
                'equivalencias',
                'gallery',
            ])
            ->where('visible', true);

        if ($this->tipo) {
            $query->where('nuevo', $this->tipo);
        }

        if ($this->categoriaId) {
            $query->where('categoria_id', $this->categoriaId);
        }

        if (!empty(array_filter($this->filtrosSubcategorias))) {
            foreach ($this->filtrosSubcategorias as $subcategoriaId => $valor) {
                if (!empty($valor)) {
                    $query->whereHas('subcategorias', function ($q) use ($subcategoriaId, $valor) {
                        $q->where('subcategorias.id', $subcategoriaId)
                          ->where('producto_subcategoria.valor', 'like', "%{$valor}%");
                    });
                }
            }
        }

        if ($this->marcaId) {
            $query->where('marca_id', $this->marcaId);
        }

        if ($this->modeloId) {
            $query->where('modelo_id', $this->modeloId);
        }

        if ($this->codigo) {
            $query->where('title', 'like', "%{$this->codigo}%");
        }

        if ($this->equivalencia) {
            $query->whereHas('equivalencias', function ($q) {
                $q->where('code', 'like', "%{$this->equivalencia}%");
            });
        }

        if ($this->search) {
            $query->where(function ($q) {
                $q->where('title', 'like', "%{$this->search}%")
                  ->orWhereHas('categoria', fn($c) => $c->where('title', 'like', "%{$this->search}%"))
                  ->orWhereHas('marca', fn($m) => $m->where('title', 'like', "%{$this->search}%"))
                  ->orWhereHas('modelo', fn($m) => $m->where('title', 'like', "%{$this->search}%"))
                  ->orWhereHas('subcategorias', fn($s) => $s->where('title', 'like', "%{$this->search}%"))
                  ->orWhereHas('equivalencias', fn($e) => $e->where('code', 'like', "%{$this->search}%"));
            });
        }

        return $query->get();
    }
}