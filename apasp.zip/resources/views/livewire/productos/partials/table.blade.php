@forelse($productos as $producto)
<tr class="hover:bg-slate-50 transition">
    <td class="px-4 py-3 text-center">
        <span class="inline-flex items-center justify-center px-2 py-1 text-xs font-medium bg-slate-100 text-slate-700 rounded">
            {{ $producto->order ?: 'N/A' }}
        </span>
    </td>
    <td class="px-4 py-3">
        @if($producto->image)
            <img src="{{ asset('storage/' . $producto->image) }}" 
                 alt="{{ $producto->title }}" 
                 class="w-16 h-16 object-cover rounded-md shadow-sm">
        @else
            <div class="w-16 h-16 bg-slate-100 rounded-md flex items-center justify-center">
                <svg class="w-8 h-8 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/>
                </svg>
            </div>
        @endif
    </td>
    <td class="px-4 py-3">
        <div class="font-medium text-slate-900">{{ $producto->code }}</div>
        <div class="flex gap-2 mt-1">
            <span class="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium {{ $producto->visible ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800' }}">
                {{ $producto->visible ? 'Visible' : 'Oculto' }}
            </span>
            <span class="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium {{ $producto->nuevo == 'nuevo' ? 'bg-blue-100 text-blue-800' : 'bg-yellow-100 text-yellow-800' }}">
                {{ ucfirst($producto->nuevo) }}
            </span>
        </div>
    </td>
    <td class="px-4 py-3">
        <div class="text-sm">
            <div class="font-medium text-slate-700">{{ $producto->marca->title ?? 'N/A' }}</div>
            <div class="text-slate-500">{{ $producto->modelo->title ?? '-' }}</div>
        </div>
    </td>
    <td class="px-4 py-3">
        <div class="text-sm">
            <div class="font-medium text-slate-700">{{ $producto->categoria->title ?? 'N/A' }}</div>
            <div class="text-slate-500">{{ $producto->subcategoria->title ?? '-' }}</div>
        </div>
    </td>
    <td class="px-4 py-3 text-center">
        <div class="text-sm">
            <div class="font-semibold text-slate-900">${{ number_format($producto->precio, 2) }}</div>
            @if($producto->descuento > 0)
                <div class="text-xs text-red-600">-${{ number_format($producto->descuento, 2) }}</div>
            @endif
        </div>
    </td>
    <td class="px-4 py-3 text-center">
        <span class="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium bg-purple-100 text-purple-800">
            {{ $producto->gallery->count() }} imgs
        </span>
    </td>
    <td class="px-4 py-3">
        <div class="flex items-center justify-center gap-2">
            <a href="{{ route('productos.edit', $producto) }}" 
               class="inline-flex items-center justify-center w-8 h-8 bg-blue-600 text-white rounded hover:bg-blue-700 transition"
               title="Editar">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/>
                </svg>
            </a>
            <button type="button" 
                    class="delete-btn inline-flex items-center justify-center w-8 h-8 bg-red-600 text-white rounded hover:bg-red-700 transition"
                    data-id="{{ $producto->id }}"
                    title="Eliminar">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/>
                </svg>
            </button>
        </div>
    </td>
</tr>
@empty
<tr>
    <td colspan="8" class="px-4 py-8 text-center text-slate-500">
        No se encontraron productos
    </td>
</tr>
@endforelse