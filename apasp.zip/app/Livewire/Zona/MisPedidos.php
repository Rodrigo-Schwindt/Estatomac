<?php

namespace App\Livewire\Zona;

use Livewire\Component;
use App\Models\Pedido;
use Illuminate\Support\Facades\Auth;
use Livewire\Attributes\Layout;

#[Layout('layouts.zone')]
class MisPedidos extends Component
{
    public function descargar($pedidoId)
    {
        $pedido = Pedido::where('id', $pedidoId)
            ->where('cliente_id', Auth::guard('cliente')->id())
            ->firstOrFail();

        if (!$pedido->descarga_habilitada) {
            $this->dispatch('show-toast', message: 'La descarga aún no está habilitada para este pedido', type: 'error');
            return;
        }

        return redirect()->route('cliente.pedidos.descargar', $pedido->id);
    }

    public function render()
    {
        $pedidos = Pedido::where('cliente_id', Auth::guard('cliente')->id())
            ->orderBy('created_at', 'desc')
            ->get();

        return view('livewire.zona.mis-pedidos', [
            'pedidos' => $pedidos,
        ]);
    }
}