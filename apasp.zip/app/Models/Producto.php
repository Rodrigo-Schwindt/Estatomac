<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Producto extends Model
{
    use HasFactory;

    protected $fillable = [
        'marca_id',
        'modelo_id',
        'code',
        'categoria_id',
        'title',
        'image',
        'order',
        'visible',
        'nuevo',
        'precio',
        'descuento',
        'destacado',
        'oferta',
    ];

    protected $casts = [
        'visible' => 'boolean',
        'precio' => 'decimal:2',
        'descuento' => 'decimal:2',
    ];

    public function marca()
    {
        return $this->belongsTo(Marca::class);
    }

    public function modelo()
    {
        return $this->belongsTo(Modelo::class);
    }

    public function categoria()
    {
        return $this->belongsTo(Categoria::class);
    }

    public function subcategorias()
    {
        return $this->belongsToMany(Subcategoria::class, 'producto_subcategoria')
                    ->withPivot('valor')
                    ->withTimestamps();
    }

    public function equivalencias()
    {
        return $this->hasMany(Equivalencia::class);
    }

    public function gallery()
    {
        return $this->hasMany(Gallery::class);
    }
}